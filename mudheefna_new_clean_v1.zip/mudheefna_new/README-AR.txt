مضيفنا — النسخة الحية

1) ارفع مجلد المشروع إلى Vercel.
2) لا تحتاج إلى Secret key. ملف config.js يحتوي فقط على Project URL وPublishable key.
3) قاعدة البيانات الحالية يجب أن تحتوي على people وpayments، ويجب إنشاء settings:

create table if not exists public.settings (
  id integer primary key check (id = 1),
  monthly_due bigint not null default 50000
);
insert into public.settings(id, monthly_due) values (1,50000)
on conflict (id) do nothing;

alter table public.settings enable row level security;
drop policy if exists "Public can view settings" on public.settings;
drop policy if exists "Authenticated can update settings" on public.settings;
create policy "Public can view settings" on public.settings
for select to anon, authenticated using (true);
create policy "Authenticated can update settings" on public.settings
for update to authenticated using (true) with check (true);

Realtime: أضف جدول settings إلى supabase_realtime إذا لم يكن موجوداً:
do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname='supabase_realtime' and schemaname='public' and tablename='settings'
  ) then
    alter publication supabase_realtime add table public.settings;
  end if;
end $$;

ملاحظة: تسجيل الدخول للإدارة يتم عبر حساب Supabase Auth الموجود عندك. عطّل تسجيل المستخدمين الجدد من Authentication → Sign In / Providers.
