// إعدادات مشروع مضيفنا — Publishable key آمن للاستخدام في المتصفح مع RLS.
window.SUPABASE_URL = 'https://jdlgtloveeizejluzzay.supabase.co';
window.SUPABASE_ANON_KEY = 'sb_publishable_PcaUS9CQ6_vBbC4UjVEC-w_0ELNKtXt';
