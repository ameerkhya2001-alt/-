-- مضيفنا: قاعدة البيانات والصلاحيات
create extension if not exists pgcrypto;

create table if not exists public.people (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  person_id uuid not null references public.people(id) on delete cascade,
  month text not null,
  amount integer not null check (amount >= 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(person_id, month)
);

create table if not exists public.settings (
  id integer primary key check (id = 1),
  monthly_due integer not null default 50000
);
insert into public.settings(id, monthly_due) values (1,50000) on conflict (id) do nothing;

alter table public.people enable row level security;
alter table public.payments enable row level security;
alter table public.settings enable row level security;

-- المشاهدة عامة، والتعديل للمدير فقط.
-- غيّر البريد أدناه إلى بريد Gmail الذي ستستخدمه لتسجيل دخول المدير.
create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select coalesce((auth.jwt() ->> 'email') = 'PUT-YOUR-ADMIN-GMAIL-HERE@gmail.com', false);
$$;

-- احذف السياسات القديمة إن وجدت ثم أعد إنشاءها.
drop policy if exists "public read people" on public.people;
drop policy if exists "admin insert people" on public.people;
drop policy if exists "admin update people" on public.people;
drop policy if exists "admin delete people" on public.people;
create policy "public read people" on public.people for select using (true);
create policy "admin insert people" on public.people for insert with check (public.is_admin());
create policy "admin update people" on public.people for update using (public.is_admin()) with check (public.is_admin());
create policy "admin delete people" on public.people for delete using (public.is_admin());

drop policy if exists "public read payments" on public.payments;
drop policy if exists "admin insert payments" on public.payments;
drop policy if exists "admin update payments" on public.payments;
drop policy if exists "admin delete payments" on public.payments;
create policy "public read payments" on public.payments for select using (true);
create policy "admin insert payments" on public.payments for insert with check (public.is_admin());
create policy "admin update payments" on public.payments for update using (public.is_admin()) with check (public.is_admin());
create policy "admin delete payments" on public.payments for delete using (public.is_admin());

drop policy if exists "public read settings" on public.settings;
drop policy if exists "admin update settings" on public.settings;
create policy "public read settings" on public.settings for select using (true);
create policy "admin update settings" on public.settings for update using (public.is_admin()) with check (public.is_admin());

-- Realtime حتى تظهر التغييرات للمشاهدين مباشرة.
alter publication supabase_realtime add table public.people;
alter publication supabase_realtime add table public.payments;
alter publication supabase_realtime add table public.settings;
